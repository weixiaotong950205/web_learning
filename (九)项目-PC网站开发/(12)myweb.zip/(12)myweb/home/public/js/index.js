//这个是index.html的特效文件
$(function(){
	$('.top .right .myjiuxian .top').mouseenter(function(){//(1)最顶部-登录小灰条-样式
		$(this).css({'background':'#fff'});
		$(this).next().show();//让我的酒仙-下拉菜单显示出来
		$(this).find('.caret').css({'transform':'rotate(180deg)'});//鼠标滑上去，让那个小三角变成倒着的三角
	});

	$('.top .right .myjiuxian').mouseleave(function(){//(1)最顶部样式
		$(this).find('.down').hide();//将下拉菜单隐藏起来
		$(this).find('.top').css({'background':'#F2F2F2'});
		$(this).find('.caret').css({'transform':'rotate(0deg)'});//移走的时候，小三角又变成了0deg
	});

	$('.navmain .center ul li').first().css({'background':'#B40C10'});//(4)幻灯片上侧的导航条-特效
	$('.navmain .center ul li').mouseenter(function(){//只有鼠标指的块变色，别的都不变色
		$('.navmain .center ul li').css({'background':'#990000'});
		$(this).css({'background':'#B40C10'});
	});

	//上面最大-幻灯片-保证运行(5)
	$('[data-toggle="carousel"]').carousel()


    // 这里是为了找出(6)幻灯片左侧导航-rightdiv的定位
	kuan=$('.leftmenu li').width();//计算leftmenu li的宽度
	x=$('.leftmenu li').first().position().left+kuan;//相对于leftmenu li中第一个块的坐标+父的宽度==rightdiv的定位；不是第一个话，rightdiv的位置会随鼠标滑动上下变化
	y=$('.leftmenu li').first().position().top;
	//alert(x+'-'+y);//这样每一个rightdiv(一共六个)都定位到190-0
	$('.leftmenu li').mouseenter(function(){//鼠标移到左侧导航，就左侧出现红色边框，并且保持整体大块不往右边移动
		$(this).find('.leftnav').show();
		$(this).find('.rightdiv').show().css({'left':x+'px','top':y+'px'});//改变rightdiv的定位坐标--默认不出现，移上去才show;注意rightdiv一定要是绝对定位；
	});
	$('.leftmenu li').mouseleave(function(){
		$(this).find('.leftnav').hide();
		$(this).find('.rightdiv').hide();
	});

	//这里是(7)幻灯片下面-标签页-特效---鼠标放到谁身上，谁多个on，多特效
	      //(7)幻灯片下标签页-左大div-大标签页
	$('.contentFirst .indexTabNav ul li').mouseenter(function(){
		$('.contentFirst .indexTabNav ul li').removeClass('on');//左上导航条-先把所有人身上的class-on去掉；注意on前面没有.
		$(this).addClass('on');//就在这个人身上加个on

		idx=$(this).index('.contentFirst .indexTabNav ul li');//鼠标移到哪个左上-标签页身上，先知道他在所有人里面排第几，
		//alert(idx);得到这是第几个标签页，去找对应号码的左下-图文显示，其他的图文都隐藏
		$('.contentFirst .indexTabConWrap').hide();
		$('.contentFirst .indexTabConWrap').eq(idx).show();
	});

	$('.contentFirst .indexTabConWrap').first().show();//(7)标签页：让第一个左下内容默认显示


	      //(7)幻灯片下标签页-右大div-右上-小标签页
	$('.contentFirst .indexTabNewNav li').mouseenter(function(){//(7)右div-小标签页-头部li
		$('.contentFirst .indexTabNewNav li').removeClass('on');//鼠标移到谁身上，就加上个属性on
		$(this).addClass('on');

		x=$(this).index('.contentFirst .indexTabNewNav li');//当鼠标往小标签页-头部移动时，找到这是第几个标签页头部
		//alert(x);
		$('.contentFirst .indexTabNewCon').hide();
		$('.contentFirst .indexTabNewCon').eq(x).show();

	})
    $('.contentFirst .indexTabNewCon').hide();/* 默认让体部先都隐藏，当鼠标点击标签页头部时，显示对应的标签页体部 */
	$('.contentFirst .indexTabNewCon').first().show();//(7)右div-小标签页-体部--默认只让第一个显示

	      //(7)幻灯片下标签页-右大div-右中-小幻灯片1
	$('[data-toggle="carousel"]').carousel()
	      //(7)幻灯片下标签页-右大div-右下-小幻灯片2
	$('[data-toggle="carousel"]').carousel()


	//(9)优惠推荐-幻灯片实现
	$('.raceBox .rightNavBox span').click(function(){//鼠标点到标题行右面小点点身上，就加上个属性on，小点点变成红色
		//关联起点点与三块幻灯片的关系
		dian=$(this).index('.raceBox .rightNavBox span');//找点点排第几
		s=-dian*v;//点击右上点点，找到该往左移多少px！！！,关联起点点与幻灯片
		//alert(s);
		$('.raceBox .raceBoxs').animate({
			'margin-left':s+'px'
		})
		//$('.raceBox .raceBoxs').css({'margin-left':s+'px'});//视图向左==.raceBoxs=3600px-往右移动了1200px
			//这样是快速的右移，要缓慢右移-animate
			
		//alert(1);
		$('.raceBox .rightNavBox span').removeClass('on');//先都移除on属性
		$(this).addClass('on');//只在鼠标点到的小点点上加上on属性
	});


	//(9)点击大长条幻灯片右侧的箭头，幻灯片1200px区域右移；
	s=0;//这上下的s/v都是一样的，要通用，要不‘点点’与‘幻灯片’不连贯了
	v=1193;//实际是198*6=1193px
	left=-2386;//往右点击最大的距离=1193*2=2386
	$('.raceBox .raceRight').click(function(){
		//alert(1);
		s-=v;
		if(s<=left){
			s=left;//右移最多只能移动两次，因为一共就三个大块的幻灯片
		}

		n=-s/v;//n是想让点击左右箭头时，上面点点会变红移动；
		//alert(n);//得到1,2
		$('.raceBox .rightNavBox span').removeClass('on');
		$('.raceBox .rightNavBox span').eq(n).addClass('on');//点箭头时，相应的点点也变红，别的点点不红

		$('.raceBox .raceBoxs').animate({//这样会达到缓慢右移的效果
			'margin-left':s+'px'
		},200);
		//$('.raceBox .raceBoxs').css({'margin-left':s+'px'});//视图向右移动==.raceBoxs=3600px---往左移动了1200px
	      //这样是一下子就右移，要慢慢的移动-用animate
	});
	$('.raceBox .raceLeft').click(function(){//点击大长条幻灯片左侧的箭头，幻灯片左移
		s+=v;
		if(s>=0){
			s=0;
		}
		n=-s/v;//这里重复上面
		//alert(n);//得到1,0
		$('.raceBox .rightNavBox span').removeClass('on');
		$('.raceBox .rightNavBox span').eq(n).addClass('on');

		$('.raceBox .raceBoxs').animate({//这样会达到缓慢左移的效果
			'margin-left':s+'px'
		},200);
		//$('.raceBox .raceBoxs').css({'margin-left':s+'px'});//视图向左==.raceBoxs=3600px---往右移动了1200px
			//同样这样是一下子就左移，要慢慢的移动
	});


	//(10)中左幻灯片-让他正常运行
	$('[data-toggle="carousel"]').carousel()
	//(10)中点击底部右上角标签，切换大长图文div
	$('.whiteWine .topTenNav a').mouseenter(function(){//鼠标移到右上角标签时
		//alert(1);
		xx=$(this).index('.whiteWine .topTenNav a');
		//alert(xx);
		$('.whiteWine .topTenCon ul').hide();
		$('.whiteWine .topTenCon ul').eq(xx).show();//相对应的那一块长图文显示，其他的都隐藏
	});
	$('.whiteWine .topTenCon ul').hide();
	$('.whiteWine .topTenCon ul').first().show();//默认大长图文div只有第一个显示，其他都隐藏



    //(11)中点击底部右上角标签，切换大长图文div---把(10)whiteWine->putaoWine
	$('.putaoWine .topTenNav a').mouseenter(function(){//鼠标移到右上角标签时
		//alert(1);
		xx=$(this).index('.putaoWine .topTenNav a');
		//alert(xx);
		$('.putaoWine .topTenCon ul').hide();
		$('.putaoWine .topTenCon ul').eq(xx).show();//相对应的那一块长图文显示，其他的都隐藏
	});
	$('.putaoWine .topTenCon ul').hide();
	$('.putaoWine .topTenCon ul').first().show();//默认大长图文div只有第一个显示，其他都隐藏


	//(12)中点击底部右上角标签，切换大长图文div---把(11)putaoWine->foreignWine
	$('.foreignWine .topTenNav a').mouseenter(function(){//鼠标移到右上角标签时
		//alert(1);
		xx=$(this).index('.foreignWine .topTenNav a');
		//alert(xx);
		$('.foreignWine .topTenCon ul').hide();
		$('.foreignWine .topTenCon ul').eq(xx).show();//相对应的那一块长图文显示，其他的都隐藏
	});
	$('.foreignWine .topTenCon ul').hide();
	$('.foreignWine .topTenCon ul').first().show();//默认大长图文div只有第一个显示，其他都隐藏


	//(13)中点击底部右上角标签，切换大长图文div---把(12)foreignWine->healthWine
	$('.healthWine .topTenNav a').mouseenter(function(){//鼠标移到右上角标签时
		//alert(1);
		xx=$(this).index('.healthWine .topTenNav a');
		//alert(xx);
		$('.healthWine .topTenCon ul').hide();
		$('.healthWine .topTenCon ul').eq(xx).show();//相对应的那一块长图文显示，其他的都隐藏
	});
	$('.healthWine .topTenCon ul').hide();
	$('.healthWine .topTenCon ul').first().show();//默认大长图文div只有第一个显示，其他都隐藏


	//(14)中点击底部右上角标签，切换大长图文div---把(13)healthWine->food
	$('.food .topTenNav a').mouseenter(function(){//鼠标移到右上角标签时
		//alert(1);
		xx=$(this).index('.food .topTenNav a');
		//alert(xx);
		$('.food .topTenCon ul').hide();
		$('.food .topTenCon ul').eq(xx).show();//相对应的那一块长图文显示，其他的都隐藏
	});
	$('.food .topTenCon ul').hide();
	$('.food .topTenCon ul').first().show();//默认大长图文div只有第一个显示，其他都隐藏


	// (15)网站下部-官方推荐长滑条-实现
		//.titleSlider滑动跟随--效果
	$('.contextThree .titleBox ul li').mouseenter(function(){
		//alert(1);
		left=$(this).position().left;// 测试每一个小标题块相对于.contextThree .titleBox ul的距离
		//alert(left);//===0,150px,210px,315,420,525,630px;
		$('.titleSlider').animate({
			left:left+'px'
		},200);
	});

		//点击右箭头-滑块向右滑动到第二块
	$('.nextPage').click(function(){
		//alert(1);
		$('.logoFirst .logoFirstbd').animate({//注意这里animate里面的写法；
			left:'-1185px'
		},200);
	});
		//点击左箭头-滑块向右滑动到第二块
	$('.prevPage').click(function(){
		//alert(1);
		$('.logoFirst .logoFirstbd').animate({//注意这里animate里面的写法；
			left:'0px'
		},200);
	});

	//鼠标往上面的酒品牌上一划，出现相应的滑动logo大div
	$('.logoBox').hide().first().show();//默认只有第一大块滑动内容显示
	$('.titleBox li').mouseenter(function(){
		var idx=$(this).index('.titleBox li');//为了避免上面同名的idx造成错误；
		//alert(idx);//0,1,2,3,4,5,6
		$('.logoBox').hide();
		$('.logoBox').eq(idx).show();
		$('.logoBox .logoFirstbd').css({'left':'0px'});//这里没有的话，点击第一个酒品牌左右箭头之后，在滑到第2,3,4,5,6,7个酒品牌上，下方的酒图文内容不出现了
	});
	   //因为图片是长图片，鼠标往上面的logo内图片上一划，图片就有向右滑动的特效
	$('.logoFirst .logoFirstbd img').mouseenter(function(){
		$(this).animate({
			left:'-100px'
		},200);
	});
	$('.logoFirst .logoFirstbd img').mouseleave(function(){
		$(this).animate({
			left:'0px'
		},200);
	});



	// (17)页脚
	     //鼠标往搜索框一点击，框内文字不见
	$('.ftRight-form input').click(function(){
		//alert(1);
		$(this).find('span').hide();//框内文字隐藏
	});



	//(18)左侧滚动监听
		//floor1---鼠标滑上去，.floor1on不隐藏了让他显示(要不点击不着)，图标出现相应的题目——白酒馆，宽度变成100
		//！！！！floor2/3/4/5都与floor1相同；
	$('.floor1').mouseenter(function(){
		hname=$(this).find('.flooron').attr('hname'); // hname:白酒馆、葡萄酒馆......
		$(this).find('.flooron').html(hname);// 这两句：鼠标滑上去，显示的是中文的白酒馆、葡萄酒馆......

		$(this).find('.floor1on').show().animate({
			'width':'100px'
		},300);
	});
		//floor1---鼠标一挪开，题目变成30px以后消失，图标变成1F，在一楼的时候是1F，不在一楼的时候是灰色图标
	$('.floor1').mouseleave(function(){
		$(this).find('.floor1on').show().animate({
			'width':'30px'
		},300,function(){  //300ms题目变成30px以后，才可以消失
			$(this).hide();
		});
	});

		//------------------------(18)-floor2---与floor1相同~~~鼠标移入-----------------------
	$('.floor2').mouseenter(function(){
		hname=$(this).find('.flooron').attr('hname'); // hname:白酒馆、葡萄酒馆......
		$(this).find('.flooron').html(hname);// 这两句：鼠标滑上去，显示的是中文的白酒馆、葡萄酒馆......

		$(this).find('.floor2on').show().animate({
			'width':'100px'
		},300);
	});
		//floor2---鼠标移出
	$('.floor2').mouseleave(function(){
		$(this).find('.floor2on').show().animate({
			'width':'30px'
		},300,function(){  
			$(this).hide();
		});
	});

		//-----------------------------(18)-floor3~~~鼠标移入------------------------------
	$('.floor3').mouseenter(function(){
		hname=$(this).find('.flooron').attr('hname'); // hname:白酒馆、葡萄酒馆......
		$(this).find('.flooron').html(hname);// 这两句：鼠标滑上去，显示的是中文的白酒馆、葡萄酒馆......

		$(this).find('.floor3on').show().animate({
			'width':'100px'
		},300);
	});
		//floor3---鼠标移出
	$('.floor3').mouseleave(function(){
		$(this).find('.floor3on').show().animate({
			'width':'30px'
		},300,function(){  
			$(this).hide();
		});
	});

		//-----------------------------(18)-floor4~~~鼠标移入------------------------------
	$('.floor4').mouseenter(function(){
		hname=$(this).find('.flooron').attr('hname'); // hname:白酒馆、葡萄酒馆......
		$(this).find('.flooron').html(hname);// 这两句：鼠标滑上去，显示的是中文的白酒馆、葡萄酒馆......

		$(this).find('.floor4on').show().animate({
			'width':'100px'
		},300);
	});
		//floor4---鼠标移出
	$('.floor4').mouseleave(function(){
		$(this).find('.floor4on').show().animate({
			'width':'30px'
		},300,function(){  
			$(this).hide();
		});
	});

		//-----------------------------(18)-floor5~~~鼠标移入------------------------------
	$('.floor5').mouseenter(function(){
		hname=$(this).find('.flooron').attr('hname'); // hname:白酒馆、葡萄酒馆......
		$(this).find('.flooron').html(hname);// 这两句：鼠标滑上去，显示的是中文的白酒馆、葡萄酒馆......

		$(this).find('.floor5on').show().animate({
			'width':'100px'
		},300);
	});
		//floor5---鼠标移出
	$('.floor5').mouseleave(function(){
		$(this).find('.floor5on').show().animate({
			'width':'30px'
		},300,function(){  
			$(this).hide();
		});
	});

		//-----------------------(18)--第6楼--.floorBack~~~鼠标移入------------------------------
	$('.floorBack').mouseenter(function(){  //.floorBack鼠标移入，图标里面变红
		$(this).find('i').css({'background-position':'-95px -190px'});
	});
	$('.floorBack').mouseleave(function(){  //.floorBack鼠标移出，图标里面变灰
		$(this).find('i').css({'background-position':'-74px -190px'});
	});


	//(18)左侧导航条--特效
		//鼠标一点击图标，滑到顶部，滑上去以后，左侧导航条消失，
	$('.floorBack').click(function(){
		$('html,body').animate({scrollTop:'0'},800); //!!!!!点击划回顶部   //!!animate写法--缓缓划回顶部
		$('.fixDiv').fadeOut(500);//左侧导航条消失;  //缓慢消失
	});
	//默认滚动监听是隐藏的；当屏幕滚动的时候，他在出现
	$(window).scroll(function(){
		sh=$(window).scrollTop();
		if(sh>300){  //当滑动超过300时，左侧的滑动监听出现；
			$('.fixDiv').fadeIn(500);
		}else{
			$('.fixDiv').fadeOut(500);
		}
	});
	
	//(18)滚动监听判断楼层，出现1F/2F/3F/4F/5F
		//每一个酒大div(10)(11)(12)(13)(14)都标一个jxfloor---class，为了收集所有楼层的高
	floortops=[];  //收集所有楼层的高
	$('.jxfloor').each(function(i){
		ot=$(this).offset().top;
		floortops[i]=ot;
	});
	//alert(floortops);  //1714;2399;3084;3769;4454

	$(window).scroll(function(){//让窗口滚动，一边滚动一边看窗口的高度
		wh=$(window).scrollTop();
		//document.title=wh;
		for(i=0;i<floortops.length;i++){//每一楼层一个for
			if(wh>=floortops[i]){  // 当滚动大于某一个楼层，就打印出楼层数
				//document.title=i;  //0,1,2,3,4
				$('.fixfloor').find('.flooron').hide(); //先找到所有的flooron，隐藏她们；
				//再到相应的楼层时，只显示出当前的xF
				name=$('.fixfloor').eq(i).find('.flooron').attr('name'); //name=1F/2F/3F/4F/5F
				$('.fixfloor').eq(i).find('.flooron').show().html(name);// 效果：这样就只有当前的xF显示，而其他不显示
			}
		}
	});


	//·····自己写的，课里没讲~~~
	//点击左侧滚动监听，页面跳到相应的画面；
	$('.fixfloor').click(function(){
		y=$(this).find('.flooron').attr('name');
		//alert(y);// 1F/2F/3F/4F/5F
		if(y=='1F'){
			$('html,body').animate({scrollTop:'1714px'},800);
		}else if(y=='2F'){
			$('html,body').animate({scrollTop:'2399px'},800);
		}else if(y=='3F'){
			$('html,body').animate({scrollTop:'3084px'},800);
		}else if(y=='4F'){
			$('html,body').animate({scrollTop:'3769px'},800);
		}else if(y=='5F'){
			$('html,body').animate({scrollTop:'4454px'},800);
		}
	});



//(19)右侧导航////////////////////////////////////////////////
	//alert($(window).height());//测有效屏幕的高度-ie~897px;
		
		//1)--‘我’样式--鼠标移入-背景变红，字变白
	$('.rSidebarItem.user').mouseenter(function(){ //class=.rSidebarItem.user名之间没有空格
		$(this).css({'background':'#c00'});
		$(this).find('.rsItemName span').css({'color':'#fff'});
			//1)我-左侧-登录界面,鼠标滑入-显示
		$(this).find('.sidebarUser').show();
	});
	$('.rSidebarItem.user').mouseleave(function(){
		$(this).css({'background':'#fff'});
		$(this).find('.rsItemName span').css({'color':'#000'});
			//1)我-左侧-登录界面,鼠标滑出-隐藏
		$(this).find('.sidebarUser').hide();
	});
	
		//2)--‘收藏’样式--重复1)的操作
	$('.rSidebarItem.collectSidebar').mouseenter(function(){ 
		$(this).css({'background':'#c00'});
		$(this).find('.rsItemName span').css({'color':'#fff'});  //只把‘收藏’两个字变白，左边弹出框的文字不变色
			//2)收藏-左侧-登录界面,鼠标滑入-显示
		$(this).find('.sidebarUserLogin').show();
	});
	$('.rSidebarItem.collectSidebar').mouseleave(function(){
		$(this).css({'background':'#fff'});
		$(this).find('.rsItemName span').css({'color':'#000'});
			//2)收藏-左侧-登录界面,鼠标划开-消失
		$(this).find('.sidebarUserLogin').hide();
	});

		//3)--‘购物车’样式
	$('.rSidebarItem.cart').mouseenter(function(){ 
		$(this).css({'background':'#c00'});
		$(this).find('span').css({'color':'#fff'});
	});
	$('.rSidebarItem.cart').mouseleave(function(){
		$(this).css({'background':'#fff'});
		$(this).find('span').css({'color':'#000'});
	});
		//4)--‘客服’样式
	$('.kefusidebar').mouseenter(function(){ 
		$(this).css({'background':'#c00'});
		$(this).find('span').css({'color':'#fff'});
	});
	$('.kefusidebar').mouseleave(function(){
		$(this).css({'background':'#fff'});
		$(this).find('span').css({'color':'#000'});
	});

	// (19)底部小图标-1
	$('.rightSidebarBot .ditu1').mouseenter(function(){ 
		$(this).css({'background':'#cf1c23'});//鼠标移入，背景变红
			//左侧-弹出框,鼠标滑入-显示
		$(this).find('.feedbackBox').show();
	});
	$('.rightSidebarBot .ditu1').mouseleave(function(){
		$(this).css({'background':'#fff'});
			//左侧-弹出框,鼠标划开-消失
		$(this).find('.feedbackBox').hide();
	});

	// (19)底部小图标-2-二维码
	$('.rightSidebarBot .ditu2').mouseenter(function(){ 
		$(this).css({'background':'#cf1c23'});
			//左侧-弹出框,鼠标滑入-显示
		$(this).find('.codeBox').show();
	});
	$('.rightSidebarBot .ditu2').mouseleave(function(){
		$(this).css({'background':'#fff'});
			//左侧-弹出框,鼠标划开-消失
		$(this).find('.codeBox').hide();
	});

	// (19)底部小图标-3-返回顶部
	$('.rightSidebarBot .ditu3').mouseenter(function(){ 
		$(this).css({'background':'#cf1c23'});
	});
	$('.rightSidebarBot .ditu3').mouseleave(function(){
		$(this).css({'background':'#fff'});
	});

	//(19)点击最后一个小图标，返回顶部
	$('.rightSidebarBot .ditu3').click(function(){
		//$('html,body').animate({scrollTop:'0'},800); //这句是-左侧导航条，点击返回顶部
		$('html,body').animate({scrollTop:'0'},500);//(法1) 模仿上句，注意animate里面的写法；
	
		// (法2) 或者这里也可以写成定时器；
		/*ws=$(window).scrollTop();
		v=50;  //注意这里没有px，是整型
		sobj=setInterval(function(){
			ws-=v;
			if(ws>0){   //没有这个if...else...就会一直返回顶部，不能往下拉
				$(window).scrollTop(ws);
			}else{
				ws=0;
				clearInterval(sobj);
			}
		},10);*/

	});


});